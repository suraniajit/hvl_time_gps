<div class="card-panel">
   
    @include('user-profile._header')
    <div class="row">
        _my-courses.blade
    </div>
</div>