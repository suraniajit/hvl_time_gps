<div class="card-panel">
    @include('user-profile._header')
    <div>
        <h5>Penalty</h5>
        <table id="penalty" class="display striped">
            <thead>
                <tr>
                    <th width="5%">No</th>
                    <th>Penalty Applied On</th>
                    <th>Penalty Amount</th>
                </tr>
            </thead>
            <tbody>
                @foreach($checkout as $key=>$check)
                <tr>
                    <td  width="5%" >{{++$key}}</td>
                    <td>{{$check->date}}</td>
                    <td>{{$check->amount}}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
        @foreach($amount as $a)
        <h6 style="float: right">Total Penalty Amount: {{count($checkout)*$a->amount}}</h6>
        @endforeach

    </div>
</div>