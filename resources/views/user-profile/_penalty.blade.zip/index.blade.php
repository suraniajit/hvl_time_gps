{{-- layout --}}
@extends('layouts.contentLayoutMaster')

{{-- page title --}}
@section('title','User Profile Page')

{{-- vendor styles --}}
@section('vendor-style')
{{--Calendar--}}

<link rel="stylesheet" type="text/css" href="{{ asset('vendors/flag-icon/css/flag-icon.min.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('css/datatable/colReorder.dataTables.min.css') }} ">
<link rel="stylesheet" type="text/css" href="{{ asset('css/datatable/buttons.dataTables.min.css') }} ">

<link rel="stylesheet" type="text/css" href="{{asset('vendors/fullcalendar/daygrid/daygrid.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('vendors/fullcalendar/timegrid/timegrid.min.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('vendors/fullcalendar/css/fullcalendar.min.css')}}">

<link rel="stylesheet" type="text/css" href="{{asset('css/pages/page-account-settings.css')}}">

@endsection

{{-- page style --}}
@section('page-style')
<style>
    .task-cat {
        padding: 9px 7px;
        /*font-size: 1.0rem;*/
    }

    .time {
        padding-left: 1% !important;
        padding-right: 1% !important;
    }

    .btn-text {
        margin-left: 5px !important;
    }

    #rel {
        margin-top: 2%;
    }

    .badge {
        position: initial !important;
    }
</style>
<link rel="stylesheet" type="text/css" href="{{asset('css/pages/app-calendar.css')}}">
@endsection

{{-- page content --}}
@section('content')
<div class="section">
    <!-- Account settings -->
    <section class="tabs-vertical mt-0 section">
        <div class="row">
            <div class="col s3">
                <!-- tabs  -->
                <div class="card-panel">
                    <ul class="tabs">
                        <li class="tab">
                            <a href="#general" class="active">
                                <i class="material-icons">brightness_low</i>
                                <span>My Info</span>
                            </a>
                        </li>
                        <li class="tab">
                            <a href="#Leave-Summary" class="">
                                <i class="material-icons">lock_open</i>
                                <span>Leave Summary</span>
                            </a>
                        </li>
                        <li class="tab">
                            <a href="#Calendar-View" class="cal">
                                <i class="material-icons">error_outline</i>
                                <span>Calendar View</span>
                            </a>
                        </li>
                        <li class="tab">
                            <a href="#My-Courses" class="">
                                <i class="material-icons">chat_bubble_outline</i>
                                <span>My Courses</span>
                            </a>
                        </li>
                        <li class="tab">
                            <a href="#My-Team">
                                <i class="material-icons">link</i>
                                <span>My-Team</span>
                            </a>
                        </li>
                        <li class="tab">
                            <a href="#My-Request">
                                <i class="material-icons">link</i>
                                <span>My-Request</span>
                            </a>
                        </li>
                        <li class="tab">
                            <a href="#penalty">
                                <i class="material-icons">link</i>
                                <span>penalty</span>
                            </a>
                        </li>
                        <li class="indicator" style="left: 0px; right: 0px;"></li></ul>
                </div>
            </div>

            <div class="col s9">
                <!-- tabs content -->
                <div id="general" class="active" style="display: block;">

                    <!--$users_roles_name[0]->user_role-->


                    <?php if (($users_roles_name[0]->user_role != 'Employee')) { ?>
                        @include('user-profile._admin-profile')
                    <?php } else if (($users_roles_name[0]->user_role == 'Employee') || (($users_roles_name[0]->user_role == 'Admin'))) { ?>
                        @include('user-profile._user-profile')
                    <?php } else { ?>
                    <?php } ?>


                </div>
                <div id="Leave-Summary" class="" style="display: none;">
                    @include('user-profile._leave-summary')
                </div>
                <div id="Calendar-View" class="" style="display: none;">
                    @include('user-profile._calendar-view')
                </div>
                <div id="My-Courses" class="" style="display: none;">
                    @include('user-profile._my-courses')
                </div>
                <div id="My-Team" style="display: none;">
                    @include('user-profile._my-team')
                </div>
                <div id="My-Request" style="display: none;">
                    @include('user-profile._my-request')
                </div>
                <div id="penalty" style="display: none;">
                    @include('user-profile._penalty')
                </div>
            </div>
        </div>
    </section> 
</div>
@endsection


{{-- page scripts --}}
@section('vendor-script')
<script src="{{asset('vendors/select2/select2.full.min.js')}}"></script>
<script src="{{asset('vendors/jquery-validation/jquery.validate.min.js')}}"></script>


<script src="{{asset('js/scripts/page-account-settings.js')}}"></script>


<script src="{{asset('js/ajax/jquery.min.js')}}"></script>
<script src="{{asset('js/ajax/angular.min.js')}}"></script>
<script src="{{asset('js/materialize.js')}}"></script>
<script src="{{asset('js/ajax/sweetalert.min.js')}}"></script>

<script src="{{asset('vendors/fullcalendar/js/fullcalendar.min.js')}}"></script>
<script src="{{asset('vendors/fullcalendar/daygrid/daygrid.min.js')}}"></script>
<script src="{{asset('vendors/fullcalendar/timegrid/timegrid.min.js')}}"></script>
<script src="{{asset('vendors/fullcalendar/interaction/interaction.min.js')}}"></script>



@endsection

{{-- page script --}}
@section('page-script')
<script src="{{asset('js/scripts/advance-ui-modals.js')}}"></script>
<script src="{{asset('js/user-profile/index.js')}}"></script>
@endsection