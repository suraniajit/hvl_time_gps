<div class="card-panel">
   
    @include('user-profile._header')
    <div class="row">
       _my-team.blade
    </div>
</div>