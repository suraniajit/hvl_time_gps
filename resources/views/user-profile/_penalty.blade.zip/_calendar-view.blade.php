<div class="card-panel">
    @include('user-profile._header')

    <div class="card">
        <div class="card-content">
            <div class="row">
                <div class="col s12">
                    <div id="basic-calendar"></div>
                </div>
                <input type="hidden" value="{{$id}}" id="id">
            </div>
        </div>
    </div>
</div>