<div class="display-flex">
    <div class="media">
        <img src="http://127.0.0.1:8000/images/avatar/avatar-7.png" class="border-radius-4" alt="profile image" height="64" width="64">
    </div>
    <div class="media-body">

        <div class="general-action-btn" style="margin-top: 8px;">

            <span>
                {{ucfirst($user['name'])}}
                <?php // echo $user['id']; ?>
            </span>
            <br>

            <?php // echo $users_roles_name[0]->user_role; ?>
        </div>
<!--                                            <small>Allowed JPG, GIF or PNG. Max size of 800kB</small>
                                                    <div class="upfilewrapper">
                                                        <input id="upfile" type="file">
                                                    </div>-->
    </div>
</div>
<div class="divider mb-1 mt-1"></div>