<div class="card-panel">

    @include('user-profile._header')
    <div>
        <h5>Leave Summary</h5>
        <table id="leavesummary" class="display striped">
            <thead>
                <tr>
                    <th style="width: 5%">ID</th>
                    <th>Leave Name</th>
                    <th>Total Leaves</th>
                    <th>Used Leaves</th>
                    <th>Remaining Leaves</th>
                </tr>
            </thead>
            <tbody>
                @foreach($leaves_master as $key=>$leave)
                <tr>
                    <td>{{++$key}}</td>
                    <td>{{$leave->Name}}</td>
                    <td>{{$leave->Number}}</td>
                    @if(!isset($sum[$key]))
                    <?php $sum[$key] = 0 ?>
                    <td>{{$sum[$key]}}</td>
                    @else
                    <td>{{$sum[$key]}}</td>
                    @endif
                    <td>{{$leave->Number-$sum[$key]}}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>