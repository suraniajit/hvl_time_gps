<div class="card-panel">
   
    @include('user-profile._header')
    <div class="row">
        _calendar-view.blade
    </div>
</div>